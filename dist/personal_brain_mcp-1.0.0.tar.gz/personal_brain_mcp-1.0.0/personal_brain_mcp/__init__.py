"""
Personal Brain MCP Server
A multimodal RAG & Personal Brain API with MCP integration for Claude Desktop.
"""

__version__ = "1.0.0"
__author__ = "Personal Brain MCP"
__email__ = "noreply@example.com"